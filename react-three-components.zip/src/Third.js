import React from 'react';
import {connect} from 'react-redux'

const Third=(props)=>{

  return (<div className='myBorderPaddingMargin'>
  <h1>I have <span>{props.count}</span> Chocolates </h1>
  </div>


  )
}
function mapStateToProps(state){

  return {count:state.counter}
}
export default connect(mapStateToProps)(Third);