const intialState={counter:233,
tasks:[],
taskTest:'Enter Name'}
const Reducer=(state=intialState,action)=>{
  const counter=state.counter;
   switch(action.type){
case 'INC': return {counter:counter+1}
case 'DEC': return {counter:counter-1}
default:return state

   }
}


export default Reducer;