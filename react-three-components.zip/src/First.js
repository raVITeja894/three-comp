import React from 'react';
import {connect} from 'react-redux'
const First = (props)=>{

  return(
    <div className='myBorderPaddingMargin'>
    <h6>first component</h6>
    <h1>{props.count}</h1>
    <button onClick={props.onIncCounter}>AddCount</button>
    <br />
    <input type='text' value={props.text}/>
    <button>AddText</button>
    </div>
  )
}
function mapStateToProps(state){

  return {count:state.counter,text:state.taskTest}
}
function mapDispatchToProps(dispatch){
  return {onIncCounter:()=>dispatch({type:'INC'})}
}

export default connect(mapStateToProps,mapDispatchToProps)(First);