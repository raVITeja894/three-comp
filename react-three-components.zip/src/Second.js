import React from 'react';
import {connect} from 'react-redux'
const Second = (props)=>{

  return(
    <div className='myBorderPaddingMargin'>
    <h6>second component</h6>
    <h1>{props.cnt}</h1>
    <button onClick={props.onDecCounter}>Dec Count</button>
    </div>
  )
}
function mapStateToProps(state){
  return {cnt:state.counter}


}

function mapDispatchToProps(dispatch){

  return {onDecCounter:()=>dispatch({type:'DEC'})}
}

export default connect(mapStateToProps,mapDispatchToProps)(Second);